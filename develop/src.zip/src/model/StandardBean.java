package model;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;

import org.primefaces.component.button.Button;
import org.primefaces.component.datatable.DataTable;
import org.primefaces.event.SelectEvent;

import model.valueobjects.StandardVO;

@ManagedBean (name="standard")
@ViewScoped
public class StandardBean implements Serializable {

	
	private static final long serialVersionUID = -2776725772598162198L;
	
	
	//List of objects
	private List<StandardVO>  list = new ArrayList<StandardVO>();
	private StandardVO selectedItem;
	
	private String testStr = "Sathyan";
	
	public String getTestStr() {
		return testStr;
	}


	public void setTestStr(String testStr) {
		this.testStr = testStr;
	}

	private List<String> testList = new ArrayList<String>();
	public List<String> getTestList() {
		return testList;
	}


	public void setTestList(List<String> testList) {
		this.testList = testList;
	}

	private Long percentId;
	
	
	public Long getPercentId() {
		return percentId;
	}


	public void setPercentId(Long percentId) {
		this.percentId = percentId;
	}


	public StandardVO getSelectedItem() {
		return selectedItem;
	}


	public void setSelectedItem(StandardVO selectedItem) {
		this.selectedItem = selectedItem;
	}


	@PostConstruct
    public void init(){
         
		//Initialise the Liset of Objects;
		System.out.println ("gggggg");
		
//		for (int i=0;i <5; i++)
//		{
//			list.add(new StandardVO(i, "Sathyan", new Date(), "888-99-0000" + i, 
//					"HR", "808-907-9000", "This is a long description first Row", true, 90));
//		
//			list.add(new StandardVO(i, "Jyothi", new Date(), "888-99-1111" + i, 
//				"HR", "808-907-9000", "This is a long description second Row", true, 90));
//		
//		}
		int i = 0;
		
		list.add(new StandardVO(i, "Sathyan, TRueblue", new Date(), "Short DESC First" + i, 
				"None", "Observation", "This is a long description first Row", true, 90));
		
		
		
		i++;
		list.add(new StandardVO(i, "Athira", new Date(), "Short DESC First " + i, 
				"Smith, John", "Conservative", "Thus us again a long Second DESC ", true, 91));
		
		i++;
		list.add(new StandardVO(i, "Zakaria", new Date(), "Short DESC First " + i, 
				"Lynch, Lichee", "Opportinuty", "Rest Long desc", true, 90));
		
		
//		list.add(new StandardVO(i, "Neil", new Date(), "888-99-0000" + i, 
//				"HR", "808-907-9000", "Celerio", true, 90));
//		
//		list.add(new StandardVO(i, "Kevin", new Date(), "888-99-0000" + i, 
//				"HR", "808-907-9000", "Premier", true, 92));
//		
//		list.add(new StandardVO(i, "Arya", new Date(), "888-99-0000" + i, 
//				"HR", "808-907-9000", "Audi", true, 90));
//		
//		list.add(new StandardVO(i, "PAppu", new Date(), "888-99-0000" + i, 
//				"HR", "808-907-9000", "Maruti Wagonr", true, 99));
//		
//		list.add(new StandardVO(i, "Motilal", new Date(), "888-99-0000" + i, 
//				"HR", "808-907-9000", "Maruti Wagonr", true, 2));
//		
//		list.add(new StandardVO(i, "Sangu", new Date(), "888-99-0000" + i, 
//				"HR", "808-907-9000", "Maruti Wagonr", true, 3));
//		
//		list.add(new StandardVO(i, "Sathyan", new Date(), "888-99-0000" + i, 
//				"HR", "808-907-9000", "Fiat", true, 90));
//		
		
		
    }
	
	public void showMe(SelectEvent event)
	{
		System.out.println("ppp");
	}
	
	public void onRowSelect(SelectEvent event)
	{
		
		HttpServletRequest request =  (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest() ;
		//Object vo  = (Object) StandardVO;
		
		this.selectedItem  = (StandardVO) (event.getObject()) ;
		
	  try {
		FacesContext.getCurrentInstance().getExternalContext().redirect("dataTables.xhtml?officeId = " + this.selectedItem.getEmpId());
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		

		//System.out.println(vo1.toString());
	}
	
	
	
	public void checked()
	{
		HttpServletRequest request =  (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest() ;
		StandardVO vo  = (StandardVO) request.getAttribute("editableList");
		
		System.out.println(vo.toString());
	}
	
	public void updateCars()
	{
		   DataTable  dataTable = (DataTable) FacesContext.getCurrentInstance().getViewRoot().findComponent("form:empList");
		   System.out.println(dataTable.getPage());
		   
		   Button button =  (Button) FacesContext.getCurrentInstance().getViewRoot().findComponent("form:two");
		   
		   if (dataTable.getPage() == 4)
		   {
			   //HtmlPanelGroup btn =  (HtmlPanelGroup) FacesContext.getCurrentInstance().getViewRoot().findComponent("form:pan");
			  //System.out.println(btn.getId());
			  
			
//			  System.out.println(btn.getId());
			  
			  button.setStyle("display:none");
		   }
		   else
		   {
			   button.setStyle("display:inline");
		   }
		   
		   //Action to save

		for (int i=0;i <50; i++)
		{
			StandardVO vo= (StandardVO) list.get(i);
			System.out.println(vo.toString());
		}
	}
	 

	public List<StandardVO> getList() {
		return list;
	}

	public void setList(List<StandardVO> list) {
		this.list = list;
	}
	
	
}
