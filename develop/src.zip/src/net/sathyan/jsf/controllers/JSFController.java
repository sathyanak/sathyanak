package net.sathyan.jsf.controllers;


public class JSFController {
	
	private String st = "sat";

	public String getSt() {
		return st;
	}

	public void setSt(String st) {
		this.st = st;
	}

}
