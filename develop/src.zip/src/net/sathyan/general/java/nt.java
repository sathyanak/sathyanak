package net.sathyan.general.java;

public class nt {

}
