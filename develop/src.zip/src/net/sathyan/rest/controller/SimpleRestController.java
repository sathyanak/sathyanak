package net.sathyan.rest.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/sathyan")
public class SimpleRestController {


	@RequestMapping(value = "/getExample", method = RequestMethod.GET)
	public String getSomething(@RequestParam(value = "request") String request,	@RequestParam(value = "version", required = false, defaultValue = "1") int version) {
		
	
		String response = null;

	
			
				response = "Response from Spring RESTful Webservice : "+ request;

			
		return response;
	}

	@RequestMapping(value = "/postExample", method = RequestMethod.POST)
	public String postSomething(@RequestParam(value = "request") String request,@RequestParam(value = "version", required = false, defaultValue = "1") int version) {
		
		String response = null;

		try {
			switch (version) {
			case 1:
			
				response = "Response from Spring RESTful Webservice : "+ request;

				break;
			default:
				throw new Exception("Unsupported version: " + version);
			}
		} catch (Exception e) {
			response = e.getMessage().toString();
		}		
		return response;
	}

}
