/*
 * Created on Aug 22, 2003
 *
 */
package net.stafftrack.fw.security.bl.constants;


public interface SystemOperations
{
	public static final Long VIEW_CONTENT = new Long(0);
	public static final Long ADD_NEW = new Long(1);
	public static final Long EDIT = new Long(2);
	public static final Long ACTIVATE_DEACTIVATE = new Long(3);
	public static final Long DELETE = new Long(4);
	public static final Long PRINT = new Long(5);
}
