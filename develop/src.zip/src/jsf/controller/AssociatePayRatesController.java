package jsf.controller;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import javax.annotation.PostConstruct ;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import model.valueobjects.AssociatePayRates;

@ManagedBean(name = "associatePayRatesController")
@ViewScoped
public class AssociatePayRatesController  implements Serializable
{
   
	 /**
		 * 
		 */
	
	  protected Long amrId = null ;
	    protected Long officeId = null ;
	    
	    
		public Long getAmrId() {
			return amrId;
		}

		public void setAmrId(Long amrId) {
			this.amrId = amrId;
		}

		public Long getOfficeId() {
			return officeId;
		}

		public void setOfficeId(Long officeId) {
			this.officeId = officeId;
		}

		private static final long serialVersionUID = 1L;
		protected Long displayedPayRateId = null;
	    protected String displayedPayRateStatus = null;
	    protected AssociatePayRates selectedAssociatePayRates = null ;
	    
		protected Long userRoleId = null;
	    private boolean hasNewValues = false;
	    private boolean hasApprovalChanges = false;
	    
	    private boolean dOApproved = false;
		private boolean sDOApproved = false;
		private boolean paApproved = false;
			
		private boolean disableDOApproval = false;
		private boolean disableSDOApproval= false;
		private boolean disableSMApproval= false;
		
		private boolean disableEditableFields = false;

		private String comment = "";

		private String stPayFromDB = "";
		private String otPayFromDB = "";
		private String dtPayFromDB = "";
		private String effectiveWkFromDB = "";
		private String effectiveYrFromDB = "";
	    
	    private Long editedOT ;

	 
	    public AssociatePayRatesController()
	    {
	        super() ;

	       
	    }

	    @PostConstruct
	    public void postConstruct( )
	    {
	        
	    }

	    
	    @PostConstruct
	    public void init(){
	         
	    	selectedAssociatePayRates  = new AssociatePayRates();
	    	
	    	selectedAssociatePayRates.setDtPay(new BigDecimal("10.06"));
	    	selectedAssociatePayRates.setOtPay(new BigDecimal("18.06"));
	    	selectedAssociatePayRates.setStPay(new BigDecimal("11.06"));
	    	
	    	//officeId = 100L;
	    }
		
	    public Long getEditedOT()
		{
			return editedOT;
		}

		public void setEditedOT(Long editedOT)
		{
			this.editedOT = editedOT;
		}

		

		public Long getDisplayedPayRateId()
		{
	    	return displayedPayRateId;
		}

		public void setDisplayedPayRateId(Long displayedPayRateId)
		{
			this.displayedPayRateId = displayedPayRateId;
		}

		public Long getUserRoleId()
		{
			return userRoleId;
		}

		public void setUserRoleId(Long userRoleId)
		{
			this.userRoleId = userRoleId;
		}

		public String getDisplayedPayRateStatus()
		{
			return displayedPayRateStatus;
		}

		public void setDisplayedPayRateStatus(String displayedPayRateStatus)
		{
			this.displayedPayRateStatus = displayedPayRateStatus;
		}

		public boolean isHasNewValues()
		{
			return hasNewValues;
		}

		public void setHasNewValues(boolean hasNewValues)
		{
			this.hasNewValues = hasNewValues;
		}

		public boolean isHasApprovalChanges()
		{
			return hasApprovalChanges;
		}

		public void setHasApprovalChanges(boolean hasApprovalChanges)
		{
			this.hasApprovalChanges = hasApprovalChanges;
		}

		public boolean isdOApproved()
		{
			return dOApproved;
		}

		public void setdOApproved(boolean dOApproved)
		{
			this.dOApproved = dOApproved;
		}

		public boolean issDOApproved()
		{
			return sDOApproved;
		}

		public void setsDOApproved(boolean sDOApproved)
		{
			this.sDOApproved = sDOApproved;
		}

		public boolean isPaApproved()
		{
			return paApproved;
		}

		public void setPaApproved(boolean paApproved)
		{
			this.paApproved = paApproved;
		}

		public boolean isDisableDOApproval()
		{
			return disableDOApproval;
		}

		public void setDisableDOApproval(boolean disableDOApproval)
		{
			this.disableDOApproval = disableDOApproval;
		}

		public boolean isDisableSDOApproval()
		{
			return disableSDOApproval;
		}

		public void setDisableSDOApproval(boolean disableSDOApproval)
		{
			this.disableSDOApproval = disableSDOApproval;
		}

		public boolean isDisableSMApproval()
		{
			return disableSMApproval;
		}

		public void setDisableSMApproval(boolean disableSMApproval)
		{
			this.disableSMApproval = disableSMApproval;
		}

		public boolean isDisableEditableFields()
		{
			return disableEditableFields;
		}

		public void setDisableEditableFields(boolean disableEditableFields)
		{
			this.disableEditableFields = disableEditableFields;
		}

		public String getComment()
		{
			
				return comment;
		}

		public void setComment(String comment)
		{
			this.comment = comment;
		}

		public String getStPayFromDB()
		{
			return stPayFromDB;
		}

		public void setStPayFromDB(String stPayFromDB)
		{
			this.stPayFromDB = stPayFromDB;
		}

		public String getOtPayFromDB()
		{
			return otPayFromDB;
		}

		public void setOtPayFromDB(String otPayFromDB)
		{
			this.otPayFromDB = otPayFromDB;
		}

		public String getDtPayFromDB()
		{
			return dtPayFromDB;
		}

		public void setDtPayFromDB(String dtPayFromDB)
		{
			this.dtPayFromDB = dtPayFromDB;
		}

		public String getEffectiveWkFromDB()
		{
			return effectiveWkFromDB;
		}

		public void setEffectiveWkFromDB(String effectiveWkFromDB)
		{
			this.effectiveWkFromDB = effectiveWkFromDB;
		}

		public String getEffectiveYrFromDB()
		{
			return effectiveYrFromDB;
		}

		public void setEffectiveYrFromDB(String effectiveYrFromDB)
		{
			this.effectiveYrFromDB = effectiveYrFromDB;
		}


		public void onSave()
	    {
			System.out.println(getSelectedAssociatePayRates().toString());
	    	
	    }
		


	    public String onSaveAssociatePayRates() throws Exception
		{
			String view = null;
			boolean isFormValid = false;

			System.out.println(getSelectedAssociatePayRates().toString());

			isFormValid = true;
			if (isFormValid)
			{
				saveAssociatePayRates(getSelectedAssociatePayRates());
				
			}
			
			return view;
		}
	    
	    public AssociatePayRates getSelectedAssociatePayRates() {
			return selectedAssociatePayRates;
		}

		public void setSelectedAssociatePayRates(AssociatePayRates selectedAssociatePayRates) {
			this.selectedAssociatePayRates = selectedAssociatePayRates;
		}

		public boolean saveAssociatePayRates( AssociatePayRates associatePayRates )
	        throws Exception
	    {
	        
				return true;
	       
	        
	    }
   

}

  
    
   

    
   
	
