package jsf.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;
import javax.faces.event.AjaxBehaviorEvent;

import org.primefaces.event.SelectEvent;
import org.primefaces.event.UnselectEvent;
import org.primefaces.model.DualListModel;
import org.primefaces.model.file.UploadedFile;

import model.valueobjects.LtHolidaysVO;


@ManagedBean(name ="generalForm")
public class GeneralForm {
   	
     
     
    private DualListModel<LtHolidaysVO> cities;
    private Date startDate;
    private String console;
    private String comments;
    
    
    public String getComments() {
		return comments;
	}
    
    
    public void ajaxListener(AjaxBehaviorEvent event) 
    {
       comments = "satyan";
    }



	public void setComments(String comments) {
		this.comments = comments;
	}



	public UploadedFile getFile() {
		return file;
	}



	public void setFile(UploadedFile file) {
		this.file = file;
	}

	private UploadedFile file;
     
    public String getConsole() {
		return console;
	}



	public void setConsole(String console) {
		this.console = console;
	}



	@PostConstruct
    public void init() {
        //Cities
        List<LtHolidaysVO> citiesSource = new ArrayList<LtHolidaysVO>();
        List<LtHolidaysVO> citiesTarget = new ArrayList<LtHolidaysVO>();
         
//        citiesSource.add("San Francisco");
//        citiesSource.add("London");
//        citiesSource.add("Paris");
//        citiesSource.add("Istanbul");
//        citiesSource.add("Berlin");
//        citiesSource.add("Barcelona");
//        citiesSource.add("Rome");
        
    
        for (int i=0;i < 5; i++)
        	citiesSource.add(new LtHolidaysVO("Sathyan", new Long(i)));
         
        cities = new DualListModel<LtHolidaysVO>(citiesSource, citiesTarget);
         
        
         
    }
 
   
    
    public Date getStartDate() {
		return startDate;
	}



	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}



	public DualListModel<LtHolidaysVO> getCities() {
		return cities;
	}



	public void setCities(DualListModel<LtHolidaysVO> cities) {
		this.cities = cities;
	}



	public void onSave()
    {
    	System.out.println("Sathya");
    	List target = cities.getTarget();
    	List source = cities.getSource();
 
    	
    	System.out.println("Sathya");
    	
    }
    
 
    public void onSelect(SelectEvent event) {
        FacesContext context = FacesContext.getCurrentInstance();
        context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Item Selected", event.getObject().toString()));
    }
     
    public void onUnselect(UnselectEvent event) {
        FacesContext context = FacesContext.getCurrentInstance();
        context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Item Unselected", event.getObject().toString()));
    }
     
    public void onReorder() {
        FacesContext context = FacesContext.getCurrentInstance();
        context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "List Reordered", null));
    } 
    
    public void upload() {
        if (file != null) {
            FacesMessage message = new FacesMessage("Successful", file.getFileName() + " is uploaded.");
            FacesContext.getCurrentInstance().addMessage(null, message);
        }
    }   
}